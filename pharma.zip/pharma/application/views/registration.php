<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
  body
  {
    background-color: #dfd9d9 !important;
  }
</style>
</head>
<div class="container" style="margin-top: 5%;">
  <div class="col-lg-3 col-md-5 col-sm-12 col-xs-12"></div>
  <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12" style="background-color:white;box-shadow: 2px 2px 18px;border-radius: 20px;padding-top: 30px;">
  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <h2 style="text-align:center;">Register</h2>
    </div>
  </div>
  <form action="welcome/register" method="POST" >
  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <label>Department</label>
      <select class="form-control" name="depart">
        <option>a</option>
        <option>b</option>
        <option>c</option>
      </select>
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <label>Email</label>
      <input type="email" class="form-control" name="email" placeholder="Email">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <label>Password</label>
      <input type="password" class="form-control" name="password" placeholder="Email">
    </div>
  </div>

<div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <center>
     <button class="btn btn-primary">Register</button>
      </center>
    </div>
  </div>
</form>
  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <a href="http://localhost/pharma/welcome/login" style="float: right;">I have an account</a>
    </div>
  </div>

</div>  
</div>

</div>