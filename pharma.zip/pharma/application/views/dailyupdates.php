<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
  body
  {
    background-color: #dfd9d9 !important;
  }
</style>
</head>
<div class="container" style="margin-top: 5%;">
 
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background-color:white;box-shadow: 2px 2px 18px;border-radius: 20px;padding-top: 30px;">
  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <h2 style="text-align:center;">Daily updates</h2>
    </div>
  </div>
  
  <form action="update_dailyreport" method="POST" enctype="multipart/form-data">
  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <label>choose one</label>
      <input type="radio" class="" name="text"  onclick="display();" id="text" value="text"> Text
      <input type="radio" class="" name="text"  onclick="display1();" id="file" value="file">File
    </div>
  </div>
   <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12" id="message">
      <label>report</label>
      <input type="text" class="form-control" name="message"  placeholder="enter report">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12" id="report">
      <label>files</label>
      <input type="file" class="form-control" name="upload"  placeholder="" >
    </div>
  </div>

<div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <center>
     <button class="btn btn-primary" id="update">update</button>
      </center>
    </div>
  </div>
</form>
</div>  
</div>

</div>


<script>
  $('#update').hide();
  $('#report').hide();
  $('#message').hide();
  function display()
  {
    $('#message').show();
    $('#update').show();
    $('#report').hide();
    
  }
  function display1()
  {
    $('#message').hide();
    $('#update').show();
    $('#report').show();
  }
</script>