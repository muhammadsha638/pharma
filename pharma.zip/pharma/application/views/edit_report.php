<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
  body
  {
    background-color: #dfd9d9 !important;
  }
</style>
</head>
<div class="container" style="margin-top: 5%;">
 
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background-color:white;box-shadow: 2px 2px 18px;border-radius: 20px;padding-top: 30px;">
  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <h2 style="text-align:center;">Edit Daily updates</h2>
    </div>
  </div>
  <?php
  foreach($fetch as $row)
  {
   ?>
  <form action="change_dailyreport?id=<?php echo $row->d_id;?>&&type=<?php echo $row->label;?>" method="POST" enctype="multipart/form-data">
 <?php
    if($row->label =='text')
    {
   
  ?>
   <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12" id="message">
      <label>report</label>
      <input type="text" class="form-control" name="message"  value="<?php echo $row->task;?>" placeholder="enter report">
    </div>
  </div>
  <?php
  }
  else
  {?>

  <div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12" id="report">
      <label>files</label>
      <input type="file" class="form-control" name="upload"  placeholder="" >
    </div>
  </div>
  <?php
  }
}
    
  ?>

<div class="form-row">
    <div class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
      <center>
     <button class="btn btn-primary" id="update">update</button>
      </center>
    </div>
  </div>
</form>
</div>  
</div>

</div>
