<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
  body
  {
    background-color: #dfd9d9 !important;
  }
</style>
</head>

<div class="container" style="margin-top: 5%;">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background-color:white;box-shadow: 2px 2px 18px;border-radius: 20px;padding-top: 30px;padding-bottom: 30px;">

<form action="filter_report" method="POST">
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
<?php
  echo "<select name=day>";
  for($i=1;$i<=31;$i++){
  $day=date('d',strtotime("first day of $i day"));
  echo "<option value=$i>$i</option> ";
  }
  echo "</select>";
  ?>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
<?php
  echo "<select name=month>";
  for($i=0;$i<=12;$i++){
  $month=date('F',strtotime("first day of +$i month"));
  $month1=date('m',strtotime("first day of +$i month"));
  echo "<option value=$month1>$month</option> ";
  }
  echo "</select>";
  ?>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
  <?php
  echo "<select name=year>";
  for($i=0;$i<=5;$i++){
  $year=date('Y',strtotime("last day of +$i year"));
  echo "<option value='$year'>$year</option>";
  }
  echo "</select>";
  ?>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
  <button class="btn btn-primary">search</button>
</div>
</div>
</form>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-top: 3%;background-color:white;box-shadow: 2px 2px 18px;border-radius: 20px;padding-top: 30px;">
<div class="table-responsive ">
  <table class="table table-bordered">
   <thead>
    <tr>
      <th colspan='5' style="text-align:center;">My Department (<?php echo $_SESSION['user_department'];?>)</th></tr>
    <tr>
    <th>Sl.no</th>
    <th>user emaiid</th>
    <th>task</th>
    <th>Type</th>
    <th colspan='2' style="text-align:center;">Action</th>
</tr>
   </thead>
   <tbody>
    <?php
    $i='1';
    foreach($fetch as $row)
    {
      if($row==null)
      {
        ?>
        <tr>
            <td>NO data</td>
        </tr>
        <?php

      }
      else
      {

      
      ?>
      <tr>
        <td><?php echo $i++;?></td>
        <td><?php echo $row->status;?></td>
        <?php
        if($row->label == 'file')
        {
          ?>
          <td><img src="http://localhost/pharma/uploads/<?php echo $row->task;?>" style="width:10%"></td>
          <?php
          
        }
        else{
          ?>
          <td><?php echo $row->task;?></td>
          <?php
        }
        ?>
        
        <td><?php echo $row->label;?></td>
        <td><a href="edit_report?id=<?php echo $row->d_id;?>" class="btn btn-primary">Edit</a></td>
        <td><a href="delete_report>id=<?php echo $row->d_id;?>" class="btn btn-danger">Delete</a></td>
        
      </tr>
      <?php
    }
}
    ?>
   </tbody>
</table>
</div>
</div>
</div>