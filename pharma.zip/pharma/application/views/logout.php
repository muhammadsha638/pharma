<?php

$this->session->sess_destroy();
redirect('/welcome','refresh');