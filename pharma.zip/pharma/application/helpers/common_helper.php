<?php

function swap($a,$b){
   
    echo "Value of a: $a</br>";
    echo "Value of b: $b</br>";
    $temp=$a;
    $a=$b;
    $b=$temp;
    echo "Value of a: $a</br>";
    echo "Value of b: $b</br>";
    // return "hai";
}
?>