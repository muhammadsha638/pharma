<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pharma_model extends CI_Model {
    public function insert_data($data)
    {
                     
    if($this->db->insert('registration',$data))
    {
        return true;
    }
    else{
        return false;
    }
    
    }

    public function check_login($email,$password,$departnemt)
    {
        
        $this->db->where('email',$email);
        $this->db->where('password',$password);
        $this->db->where('department',$departnemt);
        $query=$this->db->get('registration');
        
        if($query->num_rows()>0){
             $row =$query->row(); 
             $this->session->set_userdata('user_id',$row->r_id);
             $this->session->set_userdata('email',$row->email);
           
            return true;
            }
            else{
                return false;
            }
    } 


    public function daily_updates($data)
    {
        if($this->db->insert('daily_updates',$data))
    {
        return true;
    }
    else{
        return false;
    }
    }

    public function check_headlogin($email,$password)
    {
        
        $this->db->where('email',$email);
        $this->db->where('password',$password);
       
        $query=$this->db->get('head');
        
        if($query->num_rows()>0){
             $row =$query->row(); 
              $this->session->set_userdata('user_headid',$row->h_id);
              $this->session->set_userdata('user_department',$row->department);
           
            return true;
            }
            else{
                return false;
            }
    } 


    public function fetch_reports()
    {
        $dp=$_SESSION['user_department'];
        $this->db->select('*');
        $this->db->where('user_department',$dp);
        $query=$this->db->get('daily_updates')->result_object();
        return $query;
    }



    public function edit_report($id)
    {
        $this->db->select('*');
        $this->db->where('d_id',$id);
        $query=$this->db->get('daily_updates')->result_object();
        return $query;
    }


    public function change_dailyreport($id,$data)
    {
        $this->db->where('d_id',$id);
         if($this->db->update('daily_updates',$data))
         {
            return true;
         }
         else
         {
            return false;
         }

    }



    public function delet_report($id)
    {
        $this->db->where('d_id',$id);
        $this->db->delete('daily_updates');
    } 



    #############################filter_dailyreports########################################


    public function filter_report($day,$month,$year)
    {
       
       
        $this->db->where('date',$day.'-'.$month.'-'.$year);
        $query=$this->db->get('daily_updates')->result_object();
        // echo  $this->db->last_query();
        // exit;
        return $query;
    }
               
}
    
 
?>