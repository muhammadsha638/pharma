<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	 ########################33registerpage#################################


	public function index()
	{
		$this->load->view('registration');
	}

########################Login form#################################


	public function login()
	{
		$this->load->view('login');
	}
	public function register()
	{
		$departnemt = $this->input->post('depart',true);
        $email = $this->input->post('email',true);
        $password = $this->input->post('password',true);
		$date=date('d-m-Y');
		$this->load->model('Pharma_model');
		$data=array('department'=>$departnemt,
       
		            'email' =>$email,  
					'password' =>$password,  
					'status' =>'1',  
					'date' =>$date,  
	);
	if($this->Pharma_model->insert_data($data))
	{
		?>
		<script>alert("sucessfully registerd");</script>
		<script>window.location ="/welcome/login";</script>
		<?php
		// redirect('/welcome/login');
	}
	else
	{
		?>
		<script>alert("server issue")</script>
		<script>window.location ="index";</script>
		<?php
		// redirect('/index');
	}
	}


	########################User check login details#################################

	public function check_login()
	{
		$departnemt = $this->input->post('depart',true);
        $email = $this->input->post('email',true);
        $password = $this->input->post('password',true);
		
	if($this->Pharma_model->check_login($email,$password,$departnemt))
	{
		?>
		<script>alert("sucessfully login");</script>
		<script>window.location ="daily_updates";</script>
		<?php
		// redirect('/welcome/login');
	}
	else
	{
		?>
		<script>alert("invalid username and password")</script>
		<script>window.location ="login";</script>
		<?php
		// redirect('welcome/login');
	}
	}


########################dily update form#################################



	public function daily_updates()
	{
		$this->load->view('header');
		$this->load->view('dailyupdates');
	}


########################insert process dailyreport#################################

	public function update_dailyreport()
	{

         
		if($this->input->post('text')=='text')
		{
			$date=date('d-m-Y');
		$task=$this->input->post('message');
		$data=array('task'=>$task,
		'label' =>'text',
        'user_id' =>'2',  
	    'user_department' =>'b',  
	    'status' =>$_SESSION['email'],  
	    'date' =>$date);

       }

	   if($this->input->post('text')=='file')
		{
			
                 $config['upload_path'] = './uploads/';
                $config['allowed_types'] ='*';
                $config['file_name'] = $_FILES['upload']['name'];
                             
                $this->load->library('upload',$config);
               
                
                    if($this->upload->do_upload('upload'))
					{
                    $this->upload->data();
					
					}else
					{
					$this->upload->display_errors();
					
					}
                    
                
            
$date=date('d-m-Y');
		$data=array('task'=>$_FILES['upload']['name'],
		'label' =>'file',
        'user_id' =>'2',  
	    'user_department' =>'b',  
	    'status' =>$_SESSION['email'],  
	    'date' =>$date);

       }
		
	
if($this->Pharma_model->daily_updates($data))
	{
		?>
		<script>alert("sucessfully updated");</script>
		<script>window.location ="daily_updates";</script>
		<?php
		// redirect('/welcome/login');
	}
	else
	{
		?>
		<script>alert("server issue")</script>
		<script>window.location ="daily_updates";</script>
		<?php
		// redirect('/index');
	}


	}

	// end userside




// department head session start here


########################head login form#################################



public function headlogin()
{
	$this->load->view('head_login');
}

########################head login details check#################################

public function check_headlogin()
{
	    
        $email = $this->input->post('email',true);
        $password = $this->input->post('password',true);
		
	if($this->Pharma_model->check_headlogin($email,$password))
	{
		?>
		<script>alert("sucessfully login");</script>
		<script>window.location ="home";</script>
		<?php
		
	}
	else
	{
		?>
		<script>alert("invalid username and password")</script>
		<script>window.location ="headlogin";</script>
		<?php
		
	}
}


########################user reports view#################################

public function home()
{
$data['fetch']=$this->Pharma_model->fetch_reports();
$this->load->view('header1');
$this->load->view('home',$data);
}


########################edit eports#################################

public function edit_report()
{
	$id=$_GET['id'];
	$data['fetch']=$this->Pharma_model->edit_report($id);
	$this->load->view('header1');
	$this->load->view('edit_report',$data);
}



########################editing process#################################


public function change_dailyreport()
{
	$id=$_GET['id'];
	if($_GET['type']== 'file')
	{
		if($_FILES['upload']['name']==null)
		{
               redirect('welcome/home');
		}
		else
		{
		
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] ='*';
		$config['file_name'] = $_FILES['upload']['name'];
					 
		$this->load->library('upload',$config);
	   
		
			if($this->upload->do_upload('upload'))
			{
			$this->upload->data();
			
			}else
			{
			$this->upload->display_errors();
			
			}
			$task=$_FILES['upload']['name'];
			$data = array(
				'task' => $task,
				
		);
		
			if($this->Pharma_model->change_dailyreport($id,$data))
			{
				?>
		<script>alert("Update successfully");</script>
		<script>window.location ="home";</script>
		<?php
			}
			else
			{
				?>
		<script>alert("cant edit");</script>
		<script>window.location ="home";</script>
		<?php
			}
		}
	}
	else
	{
		$task=$this->input->post('message');
		$data = array(
			'task' => $task,
			
	);
		if($this->Pharma_model->change_dailyreport($id,$data))
		{
			?>
		<script>alert("Update successfully");</script>
		<script>window.location ="home";</script>
		<?php
		}
		else
		{
			?>
		<script>alert("cant edit");</script>
		<script>window.location ="home";</script>
		<?php
		}

       
	}
}


#############################delete dailyreports########################################

public function delete_report()
{
	$id=$_GET['id'];
	if($this->Pharma_model->delet_report($id))
		{
			?>
		<script>alert("delete successfully");</script>
		<script>window.location ="home";</script>
		<?php
		}
		else
		{
			?>
		<script>alert(" delete");</script>
		<script>window.location ="home";</script>
		<?php
		}
}



#############################filter_dailyreports########################################


public function filter_report()
{
	$day=$this->input->post('day');
	$month=$this->input->post('month');
	$year=$this->input->post('year');
	$data['fetch']=$this->Pharma_model->filter_report($day,$month,$year);
	$this->load->view('header1');
	$this->load->view('filter_data',$data);
		

}

#############################Logout########################################

public function logout()
{
	$this->load->view('logout');
}


}
